# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mrxl']

package_data = \
{'': ['*']}

install_requires = \
['lark-parser>=0.9.0,<0.10.0']

entry_points = \
{'console_scripts': ['mrxl = mrxl:main']}

setup_kwargs = {
    'name': 'mrxl',
    'version': '0.1.0',
    'description': 'map/reduce accelerator DSL',
    'long_description': None,
    'author': 'Adrian Sampson',
    'author_email': 'asampson@cs.cornell.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
}


setup(**setup_kwargs)
